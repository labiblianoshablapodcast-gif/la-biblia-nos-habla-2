# Fotografías de la versión 8.0

Las imágenes de la conversación original no fueron incluidas en el material recibido por este proyecto. Copie aquí las fotografías originales y conserve estos nombres:

- `pastor-y-yudelka-hero.jpg` — portada principal.
- `pastor-gilberto.jpg` — retrato de la biografía.
- `solorzano.jpg` — foto con el Pastor Rev. Rodolfo y Masiel Solórzano.
- `gallery-01.jpg` a `gallery-08.jpg` — imágenes para la galería.

La galería continuará funcionando automáticamente. Para agregar más imágenes, añada su información al archivo `src/gallery-data.js`.
